This section uses [mcdatapacks](https://mc-datapacks.github.io/en/index.html) standards as a checklist

This datapack is a NiT addon.

- [X] Datapack Advancement: Added advancement as per the standard. Tests ensure these are used properly.
- [X] Datapack Uninstallation: Removes any armor stands with the bloomin_town.flower_grow tag (pack specific)
- [X] Common Trait Convention: NOT NEEDED
- [X] Custom Model ID: NOT NEEDED
- [X] Global Ignoring Tag: Used in the villager in my structure and armor stands
- [X] Global Durability: NOT NEEDED
- [X] Namespace Convention: using bloomin_town namespace
- [X] Shulker Box Loot Table:  NOT NEEDED
- [X] Reloading Message: no message output
